# Your code for dectionary initialization and printing goes here
